package engineTester;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import models.TexturedModel;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import renderEngine.DisplayManager;
import renderEngine.Loader;
import renderEngine.MasterRenderer;
import renderEngine.OBJLoader;
import renderEngine.RawModel;
import terrains.Terrain;
import textures.ModelTexture;
import textures.TerrainTexture;
import textures.TerrainTexturePack;
import entities.Camera;
import entities.Entity;
import entities.Light;
import entities.Player;
import guis.GuiRenderer;
import guis.GuiTexture;

public class MainGameLoop {
	List<Entity> objectEntities = new ArrayList<Entity>(); 
	List<Terrain> objectTerrains = new ArrayList<Terrain>();
	List<GuiTexture> guis = new ArrayList<GuiTexture>();
	List<Light> lights = new ArrayList<Light>();
	
	Random random = new Random();
	public MainGameLoop() {
		
		DisplayManager.createDisplay();
		Loader loader = new Loader();
		GuiRenderer guiRender = new GuiRenderer(loader);
		
		//Guis
		GuiTexture gui = new GuiTexture(loader.loadTexture("betaPic"), new Vector2f(-.9f, .9f), new Vector2f(.10f, .10f));
		guis.add(gui);
		
		
		//Terrains
		TerrainTexture backgroundTexture = new TerrainTexture(loader.loadTexture("grassy2"));
		TerrainTexture rTexture = new TerrainTexture(loader.loadTexture("mud"));
		TerrainTexture gTexture = new TerrainTexture(loader.loadTexture("path"));
		TerrainTexture bTexture = new TerrainTexture(loader.loadTexture("grassFlowers"));
		
		TerrainTexturePack texturePack = new TerrainTexturePack(backgroundTexture, rTexture, gTexture, bTexture);
		TerrainTexture blendMapTexture = new TerrainTexture(loader.loadTexture("blendMap"));
		
		//Models
		RawModel tallGrassModel = OBJLoader.loadObjModel("grassModel", loader);
		RawModel treeModel = OBJLoader.loadObjModel("pine", loader);
		RawModel playerModel = OBJLoader.loadObjModel("person", loader);
		//Textures
		
		ModelTexture tallGrassTexture = new ModelTexture(loader.loadTexture("grassTexture"));
		tallGrassTexture.setHasTransparency(false);
		tallGrassTexture.setUsesFakeLighting(true);
		
		ModelTexture treeTexture = new ModelTexture(loader.loadTexture("pine"));
		
		ModelTexture playerTexture = new ModelTexture(loader.loadTexture("playerTexture"));
		
		//Textured models
		TexturedModel tallGrassTexturedModel = new TexturedModel(tallGrassModel, tallGrassTexture);
		TexturedModel treeTexturedModel = new TexturedModel(treeModel, treeTexture);
		TexturedModel playerTexturedModel = new TexturedModel(playerModel, playerTexture);
		
		//Entities
		Player player = new Player(playerTexturedModel, new Vector3f(50, 0, -100),  0, 0, 0, 1f);
		
		//Others
		Light light0 = new Light(new Vector3f(100, 100, 100), new Vector3f(1, 1, 1));
		Light light1 = new Light(new Vector3f(50, 0, -100), new Vector3f(1, 0, 0), new Vector3f(1, 0.01f, 0.002f));
		
		Camera camera = new Camera(player);
		
		MasterRenderer renderer = new MasterRenderer();
		
		Terrain terraintest	 = new Terrain(0, -1, loader,texturePack, blendMapTexture, "heightMap");
		
		//Loaders
		for (int k = 0; k < (5); k++) {
			float x = random.nextFloat() * 400;
			float z = random.nextFloat() * -400;
			float y = terraintest.getHeightofTerrain(-x, -z);
				objectEntities.add(new Entity(tallGrassTexturedModel, new Vector3f(x, y, z)
					, 0, 180, 0, 3));
		}

		
		
		objectEntities.add(player);
		for (int i = 0; i < 50; i++) { //Creates a bunch of trees
			float x = random.nextFloat() * 400;
			float z = random.nextFloat() * -400;
			float y = terraintest.getHeightofTerrain(x, z);
//			float y = 100;
				objectEntities.add(new Entity(treeTexturedModel, new Vector3f(x, y, z)
					, 0, 180, 0, 1));
		}
		
				
		lights.add(light0);
		lights.add(light1);
//		lights.add(light2);
		while (!Display.isCloseRequested()) {
			camera.move();
			renderer.processTerrain(terraintest);
			player.move(terraintest);
			
			if (Keyboard.isKeyDown(Keyboard.KEY_V))
				GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK,GL11.GL_LINE);
			if (Keyboard.isKeyDown(Keyboard.KEY_F))
				GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK,GL11.GL_FILL);
			if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE))
				System.exit(-1);
			
			for (Entity en:objectEntities) {
				renderer.processEntity(en);
			}
			
			renderer.render(lights, camera);
			guiRender.render(guis);
			DisplayManager.updateDisplay();
		}
		
		renderer.cleanUp();
		loader.clearnUp();
		guiRender.cleanUP();
		DisplayManager.closeDisplay();

	}
	
	public static void main(String[] args) {
		new MainGameLoop();
	}
	
}
