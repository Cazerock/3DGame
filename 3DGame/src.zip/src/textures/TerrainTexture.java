package textures;

public class TerrainTexture {
	
	private int textureID;
	
	public TerrainTexture(int id) {
		this.textureID = id;
	}
	
	public int getTextureID() {
		return textureID;
	}
	
}
