package guis;

import org.lwjgl.util.vector.Vector2f;

public class GuiTexture {
	
	private int textureId;
	private Vector2f postion;
	private Vector2f scale;
	
	public GuiTexture(int textureId, Vector2f postion, Vector2f scale) {
		this.textureId = textureId;
		this.postion = postion;
		this.scale = scale;
	}

	public int getTextureId() {
		return textureId;
	}

	public Vector2f getPostion() {
		return postion;
	}

	public Vector2f getScale() {
		return scale;
	}
	
}
